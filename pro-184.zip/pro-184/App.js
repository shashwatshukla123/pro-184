import { StatusBar } from "expo-status-bar";
import React, { Component } from "react";
import Main from "./screens/Main";

export default class App extends Component {
  render() {
    return <Main />;
  }
}
